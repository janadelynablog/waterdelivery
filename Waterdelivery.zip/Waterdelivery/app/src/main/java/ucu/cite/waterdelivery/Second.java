package ucu.cite.waterdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    ImageButton galBtn,sqrGalBtn,cirBtn,botBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        sqrGalBtn = findViewById(R.id.imageButton);
        cirBtn = findViewById(R.id.imageButton2);
        galBtn = findViewById(R.id.imageButton3);
        botBtn = findViewById(R.id.imageButton4);

        sqrGalBtn.setOnClickListener((View v) -> {
            Intent intent = new Intent (Second.this, SquareGal.class);
            startActivity(intent);


        });
        cirBtn.setOnClickListener((View v) -> {
            Intent intent = new Intent (Second.this, RoundGal.class);
            startActivity(intent);



        });
        galBtn.setOnClickListener((View v) -> {
            Intent intent = new Intent (Second.this, SmallRoundGal.class);
            startActivity(intent);



        });
        botBtn.setOnClickListener((View v) -> {
            Intent intent = new Intent (Second.this, Bottled.class);
            startActivity(intent);



        });


    }
}