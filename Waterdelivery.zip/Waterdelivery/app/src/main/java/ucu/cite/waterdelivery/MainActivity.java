package ucu.cite.waterdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText username,password;
    Button regBtn,logBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();




        username = findViewById(R.id.user);
        password = findViewById(R.id.password);
        regBtn = findViewById(R.id.register);
        logBtn = findViewById(R.id.login);







        regBtn.setOnClickListener((View v) -> {
            String name = username.getText().toString();
            String pass = password.getText().toString();


            if (name.isEmpty() || pass.isEmpty()){
                Toast.makeText(this, "Please Fill up required info", Toast.LENGTH_LONG).show();
            }else{
                editor.putString("Name", name);
                editor.putString("Password", pass);
                editor.apply();

                Intent intent = new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);

                Toast.makeText(this, "Saved Succesfully", Toast.LENGTH_LONG).show();

            }
        });

        String myusername = pref.getString("Name", null);
        String mypass = pref.getString("Password", null);


        logBtn.setOnClickListener((View v) -> {
            String userN = myusername;
            String passW = mypass;

            String Ename = username.getText().toString();
            String Epass = password.getText().toString();

            if (userN== null && passW==null){
                Toast.makeText(this, "Please Register First", Toast.LENGTH_LONG).show();
            }else if(Ename.equals(userN) && Epass.equals(passW)){
                Intent intent = new Intent(MainActivity.this, Second.class);
                startActivity(intent);

            }else{
                Toast.makeText(this, "Check your credentials", Toast.LENGTH_LONG).show();

            }
        });
    }
}