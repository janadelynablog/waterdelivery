package ucu.cite.waterdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RoundGal extends AppCompatActivity {
    Button cancelBtn,proceedBtn;
    EditText quantity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_round_gal);

        cancelBtn = findViewById(R.id.cancel);
        proceedBtn = findViewById(R.id.proceed);
        quantity = findViewById(R.id.quant);



        cancelBtn.setOnClickListener((View v) -> {
            Intent intent = new Intent(RoundGal.this,Second.class);
            startActivity(intent);
            finish();


        });

        proceedBtn.setOnClickListener((View v) -> {

            int quant = Integer.parseInt(quantity.getText().toString());
            int price = 225;
            int total = price * quant;

            String finalPay = Integer.toString(total);

            Intent intent = new Intent(RoundGal.this,InfoReview.class);
            intent.putExtra("Total", finalPay);
            startActivity(intent);
            finish();

        });
    }
}