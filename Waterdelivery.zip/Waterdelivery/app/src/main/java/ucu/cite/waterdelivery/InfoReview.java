package ucu.cite.waterdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class InfoReview extends AppCompatActivity {
    EditText address;
    TextView pays;
    Button cancel, placeOrd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_review);

        address = findViewById(R.id.addr);
        cancel = findViewById(R.id.back);
        placeOrd = findViewById(R.id.placeorder);
        pays = findViewById(R.id.pay);

        String deliverAddr = address.getText().toString();

        Intent pay = getIntent();
        String totalPay = pay.getStringExtra("Total");

        pays.setText(totalPay);

        cancel.setOnClickListener((View v) -> {
            Intent intent = new Intent(InfoReview.this,Second.class);
            startActivity(intent);
            finish();

        });

        placeOrd.setOnClickListener((View v) -> {
            Intent intent = new Intent(InfoReview.this,ThankYou.class);
            startActivity(intent);
            finish();

        });

    }
}